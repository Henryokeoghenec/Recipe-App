# recipes_app

Simple Recipes App made in Flutter for a series of articles. You can find all articles [here](https://medium.com/@michael.krol).

Branches are regarding to articles:

01_introduction - [Simple Recipes App made in Flutter — Introduction](https://medium.com/@michael.krol/simple-recipes-app-made-in-flutter-introduction-c80964167a19)

02_list_detail_view - [Simple Recipes App made in Flutter  —  List View](https://medium.com/@michael.krol/simple-recipes-app-made-in-flutter-list-view-283ef85f91e7)

03_firebase - [Simple Recipes App made in Flutter  —  Firebase and Google Sign-In](https://medium.com/flutter-community/simple-recipes-app-made-in-flutter-firebase-and-google-sign-in-14d1535e9a59)

04_firestore - [Simple Recipes App made in Flutter  —  Firestore](https://medium.com/flutter-community/simple-recipes-app-made-in-flutter-firestore-f386722102da)

05_settings - [Simple Recipes App made in Flutter   —  Detail View and Settings Widget](https://medium.com/flutter-community/simple-recipes-app-made-in-flutter-detail-view-and-settings-widget-9a7ca9ebec93)

## Final result

![Screenshots](https://cdn-images-1.medium.com/max/800/1*QD-R8NARXpMC7lyXjrfnpg.png)
